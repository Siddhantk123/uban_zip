#/usr/bin/perl

#Title
print("\n\t\tWelcome to Sid's & Adi's restro Guest list\n\n");
print("\t\t\tDesigned by: Siddhant & Aditi\n\n\n\n");


sub options
{
print("1-Search for customer.\n");
print("2-.Add new customer\n");
print("3-Get all customer.\n");
print("4-Quit.\n\n");

print("Select an option: ");
$user_inp= <STDIN>;
return $user_inp;
}




#-------------------begin----------------------------------------------------
while ($a==0)
{
$opt= options();
print($opt);
	if ($opt == 1)
	{
	search_for_customer();
	} 
	elsif ($opt==2)
	{
	add_new_customer();
	}
	elsif ($opt==3)
	{
	get_all_customer();
	}
	elsif ($opt==4)
	{
	$a=1;
	}
	else
	{
	print("\n Wrong Choice. Please select the correct option.\n\n");
	}
}




#---------------------Subroutins--------------------------------------------------


sub search_for_customer
{
print("\n\nEnter the name of Customer: \n\n");
$cus_name=lc(<STDIN>);
$check=0;
open (fh,'<',"cusname.txt");
	{
while ($c = <fh>)
	{
	#print($c);
	#print($cus_name);

	if($cus_name eq $c)
			{
			$check=1;
		
			}		
	}
if ($check eq 1)
{
	printf("\n%s was found!!\n\n",$cus_name);
}
else
{
	print("\nNot found\n\n");
}	
}
close(fh);

}


sub add_new_customer
{
print("Enter the name of new Customer: ");
$new_customer=<STDIN>;
open(h,'>>',"cusname.txt");
{

print(h $new_customer);

}
close(h);

}


sub get_all_customer
{
open (fh,'<',"cusname.txt");
	{
while ($c = <fh>)	
	{		
print("$c\n");
	}


	}
}



































