
#Write a program that reads a series of words (with one word per line) until End-OfFile, and 
#then prints a summary of how many times each #word was seen. 
#(For an extra challenge, sort the words into ascending ASCII order in the output).

$count=5;
while($count>0)
{
print("Enter a word\n");

chomp ($inp = <>);
$dict{$inp}++;
$count--;
}
print("You have reached till the end of the file\n\n");

print("Summary\n");

while(($key,$value) = each %dict)
{
print ("$key => $value\n");

}
