


#!/usr/bin/perl
use warnings;
use strict;

my @a = (1,3,2,6,8,4,9);

my $m = &max(\@a);

print "The max of @a is $m\n";

sub max{
    my $aref = $_[0];
    #print("$aref\n");
    my $k = $aref->[0]; #$k store the value of the first element
    #print("$k\n");
#looping.................
    for(@$aref){
    if($k < $_)
    	{
         $k = $_;
       } 
    }
    return $k;
}
