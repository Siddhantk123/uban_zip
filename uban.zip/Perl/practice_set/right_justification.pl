#Write a program that reads a list of strings, and prints the strings
#in a right justified, 20 character column.
#For example, inputting hello (new line) goodbye (new line) prints hello on
#one row, and goodbye on the next row, both aligned such that the o and e are in
#the same (19th) column.



print("Please enter 1st  word\n");
chomp ($inp1 = <>);
$len1 = length($inp1);
print("Please enter 2st  word\n");
chomp ($inp2 = <>);
$len2 = length($inp2);
print("Hey user baba, what length of line do you want\n");
$lin_len = <>;
$sp1= $lin_len - $len1;
$sp2= $lin_len - $len2;

$v1 = " " x $sp1;
$v2 = " " x $sp2;

print("$v1$inp1\n");
print("$v2$inp2\n");




#if( $len1 > $len2)
#{
#$subt = $len1 - $len2;
#$i2 = " " x $subt;
#print("$i2$inp2\n");
#print("$inp1\n");
#}
#else
#{
#$subt = $len2 - $len1;
#$i1= " " x $subt;
#print("$i1$inp1\n");
#print("$inp2");
#}
