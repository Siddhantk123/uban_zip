#method 1
#!/usr/bin/perl

print("Please enter the value of X\n");
chomp ($x = <>);
$dict{"x_value"}= $x;

print("Please enter the value of slope\n");
chomp($m = <>);
$dict{"slope"}= $m;

print("Please enter the value of constent\n");
chomp($c = <>);
$dict{"const"}= $c;
while(($k , $v) = each (%dict))
{
#print("$k , $v\n");
}


#passing the refrence of a hash to the subroutine
hash(\%dict);

sub hash
{
#print("$_[0]\n");

#by refrencing method
$y = $_[0] -> {"x_value"}*$_[0]->{"slope"} + $_[0] ->{"const"};
print("\n$y\n");

#by de-refrencing method (another method)
($h)=@_;                      # $h is a address/ refrence
 %h = %$h;                     #de-refrencing hash

$y1 = $h{"x_value"} * $h{"slope"} + $h{"const"};
print("$y1\n");

}


















#method2

#print("Please enter the value of X\n");
#chomp ($x = <>);
#print("Please enter the value of slope\n");
#chomp($m = <>);
#print("Please enter the value of constent\n");
#chomp($c = <>);


#%line = ("x_value" => $x , "slope" => $m , "const" => $c );
#while(($k , $v) = each (%dict))
#{
#print("$k , $v\n");
#}
#passing the refrence of a hash to the subroutine
#hash(\%dict);

#sub hash
#{
#print("$_[0]\n");
#$y = $_[0] -> {"x_value"}*$_[0]->{"slope"} + $_[0] ->{"const"};
#print("$y\n");
#}
