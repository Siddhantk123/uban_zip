#!/usr/bin/perl
#hash_re->subroutine->return out some value

%dict=("principal"=> 100000, "rate"=> 5, "t"=> 3);

sub interest
{
#print("$_[0]\n");
$amt = $_[0]->{"principal"} + ($_[0]->{"principal"} * $_[0]->{"rate"} * $_[0]->{"t"}) / 100;
print("Amount: $amt\n");

}

interest(\%dict);

