#Write a program tht reads and prints a string, and it’s mapped value,
#according to the mapping presented below.
#Input       Output
#Red         Apple
#Green       Leaves
#Blue        Ocean

%map=('red' => 'apple','green' => 'leaves', 'blue' => 'ocean' );
print("A string please: ");
chomp($input = <>);
#$input = <>;
print($map{lc($input)},"\n");

