#!/usr/bin/perl
sub num_sum
{
$num=0;
while($num eq 0)
{	
print("Please enter the number to be added or press 999 to calculate total sum\n");
	$n=<>;
	if ($n != 999)
	{
	$sum=$sum+$n;
	}
	else
	{
	$num=1;
	}

}
print("Total Sum is: $sum\n");
}
#num_sum()









sub freq_count
{
	use List::Util qw(max);

	# Perl program for counting words in a string 
	  
	$actual_text = "hi kaise hi ho kaise acha hoon tha acha rahunga" ; 
	  
	# Creating words array by splitting the string 
	@words= split / /, $actual_text; 
	   
	# Traversing the words array and  
	# increasing count of each word by 1 
	foreach $word(@words)  
	{ 
	    ++$count{$word}; 
	    
	} 
	# Now our hash %count is ready"
	#inorder to understand its key and value we are writing the below code
	while ( ($k,$v) = each %count ) {
	    print "$k => $v\n";
	    #push(@key,$k);
	    #push(@value,$v); 
	}

	print("\nAfter sorting\n\n");

	  
	# Printing the word and its actual count(frequency) 
	foreach $word (sort keys %count)  
	{ 
	    print $word, " ", $count{$word}, "\n"; 
	} 
	
	#Now printing the keys of highest occurance value
	
	$maxi = max(@value);
	
	foreach $key (keys %count)
	{
		#print("$val\n");
		if($count{$key}==$maxi)
		{
		print($key,"\n");
		}
	}
	
	
	
}
#freq_count()

Sub check
{

print("hiiiiiiiiiiii");
}

check()





























