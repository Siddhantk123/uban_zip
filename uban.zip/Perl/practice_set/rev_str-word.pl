use POSIX;
#reversing the string along with each word from the string.

$str="siddhant, your name is motu for aditi";
#string to array
@arr1= split(" ",$str);

$len=@arr1;
$l=$len-1;
 

#iterate
for($i = $l ; $i >= 0 ; $i--)
{

$word=@arr1[$i];
@arr2= split("",$word);
$len1=@arr2;
$l1=$len1-1;
	for($j = $l1 ; $j >= 0 ; $j--)
	{
	 print(@arr2[$j]);
	}
print("\t");

}














