print("who are you, a bird, a human or a fish\n");
chomp($type = <>);
category(\$type);
sub category
{
($var) = @_;
#print("$var");
if($$var eq "bird")
{
print("You can Fly, In the sky\n");
}
if($$var eq "human")
{
print("You are of no use, lol :) \n ");
}
if($$var eq "fish")
{
print("You can swim, In the water \n");
}

}
