#Finding the maximum value from the array using reference concept.
#!/usr/bin/perl
use warnings;
use strict;

my @a = (1,3,2,6,7);  #simple array
my @b = (8,4,9);

my @c = pops(\@a,\@b);    #passing refrence/address of an array to the subroutine
print("@c \n"); # 7, 9

sub pops{
    my @ret = ();	
    for my $aref(@_)
    {
        push(@ret, pop @$aref);
        #print("@$aref\n");
    }
    return @ret;
}
