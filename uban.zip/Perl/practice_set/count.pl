#!/usr/bin/perl
$str= "hi hi hi aditi ke siddhu, siddhu piddu hi";
@arr= split(" ", $str);
foreach $word (@arr)
{
$count{$word}++;
}

foreach $word (keys %count)
{
print("$word => $count{$word}\n");
}




