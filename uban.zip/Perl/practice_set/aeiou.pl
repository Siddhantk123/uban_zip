
#find and return the line which contain 'aeiou' in any order

#!/usr/bin/perl

sub prnt
{
$_= shift;
if (/a*e*i*o*u/sg)
{
print "$_\n";
}
}

&prnt("print this is a o");
&prnt("alleiw hiou tahis oae");
&prnt("hi hello aeidofu");
&prnt("hpp");






