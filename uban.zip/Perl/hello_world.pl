#!usr/bin/perl

print("What is your name?\n\n");
$name=<STDIN>;
print("Hello,", $name ,"how are you?\n\n");

