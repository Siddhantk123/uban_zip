#!/use/bin/perl
@arr1=("man", "girl");
push(@arr1, "boy");
print("@arr1\n");











