#!/usr/bin/perl

$s="aditi";
#converting string to array
@arr=split("",$s);
print("@arr ");









