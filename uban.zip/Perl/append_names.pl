#!/usr/bin/perl
open($fh, ">>" ,"test.txt");


print($fh "\nShivani Mishra\n");
print($fh "Henna Sharma\n");


close($fh);



