#sorting & merging
#sorting

@element=(2,4,5,1,7,23,89,23,12);
print("@element\n");
@element=sort(@element);
print("@element\n");

#merging

@arr1=("ram", "sita", "lakshman");
@mrg= (@arr1, @element);
print("@mrg\n");
