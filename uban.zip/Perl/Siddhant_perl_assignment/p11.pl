#We have Array of arrays , print the Index of array with elements having largest Sum.
@items = ([1,4,9],[10,12,45,10],[4,89,5,10],[58,66,10]);


#!/usr/bin/perl
$len= @items;
$maxi= 0;
$index=0;
for($i=0; $i < $len; $i++)
{
	$sum=0;
	@ar = @items[$i];
	$len1= @ar;
	for($j=0; $j< $len1; $j++)
	{
		$sum= $sum+ $ar[$j]; 
	}
	if($sum gt $maxi)
	{
		$maxi=$sum;
		$index=$i;
	}
	
	
}

print("Index of array with elements having largest Sum is : $index\n");
