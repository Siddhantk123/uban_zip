#Below is the hash containing Marks of 'Maths','Physics' and Chemistry of 5 Students.
#   Print the Student with largest combined marks in PCM(All Subjects)
#    %hash = ('John' => {'Maths' => 40,
#                        'Physics' => 60,
#                        'Chemistry' => 20,
#                        },
#             'Harry' => {'Maths' => 45,
#                        'Physics' => 50,
#                        'Chemistry' => 27,
#                        },
#             'Jacob' => {'Maths' => 60,
#                        'Physics' => 75,
#                        'Chemistry' => 90,
#                        },
#             'Thomas' => {'Maths' => 52,
#                        'Physics' => 56,
#                        'Chemistry' => 98,
#                        },
#             'George' => {'Maths' => 72,
#                         'Physics' => 61,
#                         'Chemistry' => 59,
#                         },  
#    
#            );

#!/usr/bin/perl
use List::Util qw(max);
%hash = ('John' => {'Maths' => 40,
                      'Physics' => 60,
                        'Chemistry' => 20,
                        },
             'Harry' => {'Maths' => 45,
                        'Physics' => 50,
                      'Chemistry' => 27,
                        },
             'Jacob' => {'Maths' => 60,
                        'Physics' => 75,
                        'Chemistry' => 90,
                        },
             'Thomas' => {'Maths' => 52,
                        'Physics' => 56,
                        'Chemistry' => 98,
                        },
             'George' => {'Maths' => 72,
                         'Physics' => 61,
                         'Chemistry' => 59,
                         },  
    
            );
            
@key= keys %hash;
$len=@key;
foreach my $i(@key)
{

	@sum= ${$hash{$i}}{'Maths'}+ ${$hash{$i}}{'Physics'}+ ${$hash{$i}}{'Chemistry'};
	push(@val, @sum);

}
$m=max(@val);
#print("$m\n");

for($j=0; $j<$len; $j++)
{
	if($val[$j] eq $m)
	{
	$index= $j;
	}
}	

print("Student with largest combined marks in PCM(All Subjects):\n@key[$index]\n");
        








