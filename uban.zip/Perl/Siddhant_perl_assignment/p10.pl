#We have a Array of hashes , Print the Value of key 'husband' of each hash.
@AoH = ( { husband => "barney", wife => "betty", son => "bamm bamm", },
         { husband => "george", wife => "jane", son => "elroy", },
         { husband => "homer", wife => "marge", son => "bart", }, );
             
             
#!/usr/bin/perl

$len=@AoH;
for($i=0; $i < $len; $i++)
{

	$val = ${AoH[$i]}{husband};
	print("$val\n");
	
}


             
