#Find the 2nd most Occurred letter in String.
#$string = 'aaabbbbcc' , o/p = 'a'
#In above example 'a' occurred 3 times , b occurred 4 times and c occurred 2 times.

#!/usr/bin/perl
print("Enter the string\n");
chomp($string = <>);
@arr1= split("", $string);


foreach $word(@arr1)
{
	++$dict{$word};
}

@d=sort values %dict;
$len=@d;
@key= keys %dict;
#print("@d\n");
$s= @d[$len-2];     #most second occured index number
print("2nd most Occurred letter in String: ");
foreach $w(@key)
{
	if($dict{$w} == $s)
	{
		$mo= $w;
		print("$mo\t");
	}
}
print("\n");




