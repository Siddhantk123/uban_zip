#Find Common and Different keys in two hashes.
    #%hash1 = ( Lemon => "yellow",
               #Orange => "orange",
               #Lime => "green" );
               
    #%hash2 = ( Lemon => "yellow",
               #Orange => "orange",
               #Guava => "green" );
               
                              
#!/usr/bin/perl          
#taking hash input     
print("Please enter the size of 1st hash: ");
chomp($size1=<>);
for($i=1;$i <= $size1; $i++)
{
	print("Enter element"," ",$i," " ,"of the hash_1\n");
	chomp($el=<>);
	print("Enter value of element"," " ,"$i: ");
	chomp($elv=<>);
	
	$hash1{$el}=$elv;
	
}         
print("\n\nPlease enter the size of 2st hash: ");
chomp($size2=<>);
for($i=1;$i <= $size2; $i++)
{
	print("Enter element"," ",$i," " ,"of the hash_2\n");
	chomp($el2=<>);
	print("Enter value of element"," " ,"$i: ");
	chomp($elv2=<>);
	
	$hash2{$el2}=$elv2;
	
}          
                        
#coding logic         
               
@key1= keys %hash1;
@key2= keys %hash2;
#nesting over and comparing
foreach $k1(@key1)
{
	foreach $k2(@key2)
	{
		
		if($k2 eq $k1)
		{
			push(@common, $k1);
		}
		else
		{
			$al{$k1} = 0;
			$al{$k2} = 0;
		}
	}
}  

print("\nCommon keys in two hashes are:\n");             
print("@common\n");
print("\nDifferent keys in two hashes are:\n");             
@al = keys %al;
$la=@al;
$lc= @common;
for($j=0; $j < $la; $j++)
{	$r=0;
	for($k=0; $k<$lc; $k++)
	{
		if($al[$j] eq $common[$k])
		{
			$r=1;
			last;
			
		}
	}
	if ($r eq 0)
	{
	push(@diff, $al[$j]);
	}

}
print("@diff\n");








