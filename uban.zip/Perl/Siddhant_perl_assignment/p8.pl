#Read the file content and create list of all the IP addresses found
#   output : ('10.116.59.58','10.116.59.59','10.116.59.70','10.116.59.90')

#    Sample File Content :
#   =========================================
#    Withdrawing address record for 10.116.59.58 on eno1
#    Withdrawing workstation service for eno1
#    Withdrawing workstation service 10.116.59.59 for lo
#    Host name conflict, retrying with jaguar9999-239
#    Registering new address 10.116.59.70 record for fe80::e9e8:1d6a:2b35:f49a on eno1
#    Registering new address record for 10.116.59.90 on eno1.IPv4
#    Registering HINFO record with values 'X86_64'/'LINUX'
#    Server startup complete. Host name is jaguar9999-239.local
#    ==================================================================

#!/usr/bin/perl
open(fh,'<','p8.txt');
while($data=<fh>)
{
chomp($data);

if ($data =~ /(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})/)
{
$data= $1;
push(@ip, $data);
}

}
print("@ip\n");
close($_);

