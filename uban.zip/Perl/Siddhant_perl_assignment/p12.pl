#We have a hash with Students and Age , Sort the Students based on the age and return a list of Students.
#    Output - ('John','Thomos','Harry','Jacob')

    %hash = ('John' => 19,
             'Harry' => 40,
             'Thomos' => 20,
             'Jacob'  => 50,
            );


@val=values %hash;
@val=sort @val;
$len=@val;
for($i= 0; $i<$len; $i++)
{
	foreach $word(keys %hash)
	{
		if($hash{$word} eq $val[$i])
		{
			push(@srt_stu, $word);
		}
	}
}

print("@srt_stu\n");
