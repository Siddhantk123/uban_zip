#!/usr/bin/perl
#Reverse a Word Order in String 
#$string = 'John said can you see this';
#output : ‘this see you can said John’

print("Please enter the string\n");
$string = <>;
@str= split(" ", $string);

$len=@str;
for($i = $len-1; $i >= 0; $i-- )
{
    push(@s, $str[$i]);
}
print("@s\n");

print("\n\nMethod 2\n");

print("Please enter the string\n");
$string= <>;
@str= split(" ", $string);
$len=@str;

foreach $w(@str)
{
unshift(@a,$w);
}
print("@a\n"); 
