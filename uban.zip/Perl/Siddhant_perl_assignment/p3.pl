#Write a Subroutine , which accepts a list of numbers and one integer argument (example: k).You need to return a list
#contains square of every kth element of the input list.
#@arr = (1,2,3,4,5,6,7,8,9)
#k = 2
#output : (4,16,36,64)



#!/usr/bin/perl
print("Please specify the length of an array: ");
chomp($l=<>);
for($i=0; $i<$l; $i++)
{
	print("please enter"," ",$i+1," ","element\n");
	chomp($inp=<>);
	push(@arr, $inp );
}
print("PLease enter the value of kth element: ");
chomp($k=<>);

#@arr = (1,2,3,4,5,6,7,8,9);
#$k = 2;

sub sqr
{
($a,$b)=@_;
@ar= @$a;
$ki= $$b;
#print("@ar , $ki\n");
$len= @ar;

for($i=$ki-1; $i<$len; $i=$i+$ki)	
{	
	push (@arr2, $ar[$i] * $ar[$i]);
		
}
print("square of every kth element of the input list is-\n");
print("@arr2\n");


}

sqr(\@arr, \$k);

