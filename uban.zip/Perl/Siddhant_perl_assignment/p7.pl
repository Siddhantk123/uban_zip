#Read the file content and create hash having key as 'Name' and respective values as 'City'
#   Sample File Content:
#   =============================
#    John lives in Indore
#    Harry lives in Delhi
#    Thomos lives in Bangalore
#    Jacob lives in Bombay
#    ===============================
# Output : 
#    %hash = ('John' => 'Indore',
#             'Harry' => 'Delhi',
#             'Thomos' => 'Bangalore',
#             'Jacob'  => 'Bombay'
#             );

open(fh,'<','p7.txt');

while(<fh>)
{
#print(<fh>,"\n");
@arr = split(" ", <fh>);
$hash{$arr[0]}= $arr[3];
}
close(fh);

while(($k,$v) = each(%hash))
{

	print("$k  $v \n");
}














