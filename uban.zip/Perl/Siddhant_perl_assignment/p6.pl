 #Open a File and print all the Lines starts with 'Withdrawing' and ends with 'eno1'.
 #   Sample File Content :
 #   =========================================
 #   Withdrawing address record for 10.116.59.58 on eno1
 #   Withdrawing workstation service for eno1
 #   Withdrawing workstation service for lo
 #   Host name conflict, retrying with jaguar9999-239
 #   Registering new address record for fe80::e9e8:1d6a:2b35:f49a on eno1
 #   Registering new address record for 10.116.59.58 on eno1.IPv4
 #   Registering HINFO record with values 'X86_64'/'LINUX'
 #   Server startup complete. Host name is jaguar9999-239.local
 #   ==================================================================
 
 
 #!/usr/bin/perl
 
 open(fh,"<", "p6.txt");
 while($line = <fh>)
{

	if ($line =~ m/Withdrawing.*eno1/gmi) 
            {
            print ("$line\n");
            }

}
close(fh);
