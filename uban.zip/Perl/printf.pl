

printf("Hi %s. You are %d years old.\n",siddhant,22);
