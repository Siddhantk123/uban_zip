while(defined($data= <>))
{
	print($data);
	
}
