@arr2=qw/ shivani sristi sakshi mahima aditi /;
pop(@arr2);
print("@arr2\n");



