lis1= [
    ["banana","grapes"],
    ["boy","girl","spam"],
    ["spam","male","female"],
    ["good","bad"]
]
print("Original list:\n\n",lis1)
#task is to remove spam from the list and print the list
for item in lis1:
    for sub_item in item:
        if sub_item == 'spam':
            item.remove(sub_item)

print("\nlist value ater deleting spam:\n\n",lis1)           