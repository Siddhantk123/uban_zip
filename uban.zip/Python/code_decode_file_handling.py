#intro
# f= open("a.txt","w")
# f.write("hi aditi u are very sweet")
# f.close()
with open("general.txt","r") as f:
    li=[]
    u_inp= f.read() #return string
    for letter in u_inp:
        if letter == " ":
            li.append(letter)          
        else:
            order= ord(letter)
            order= order+1
            char= chr(order)
            li.append(char)   #converting to list
enc_output= "".join(li)  #converting to string


with open("encrypt.txt","w") as f:

    f.write(enc_output)



















    
