#binary search
li=[1,2,5,9,10,20,50,67,90]  #assending order
length= len(li)
low = 0
high = length - 1
srh = int(input("Enter the number you want to search in the list: "))
if srh in li:

    while True:
        mid = (low + high)//2
        if li[mid] == srh:
            print("This number found in the list at index no: {} ".format((low+high)//2))
            break
        elif srh > li[mid]:
            low =mid +  1
        else:
            high = mid -1
            
else:
    print("This number {} doesnot exist in the list".format(srh))
                
        


        