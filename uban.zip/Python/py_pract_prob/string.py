str1="hi, how :,,'' are you.....''.,.,.,.,.."
li=[]
for i in str1:
    if (i != ";" ) and ( i != ".") and (i !=  "'") and (i != ",") and (i != ":"):
        li.append(i)

str2 = " ".join(li)
str2.replace("  "," ")
print(str2)