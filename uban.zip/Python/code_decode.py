#encryption and decryption
def encryption():
    li=[]
    u_inp=input("Please enter your text to be encrypted\n")
    for letter in u_inp:
        if letter == " ":
            li.append(letter)          
        else:
            order= ord(letter)
            order= order+1
            char= chr(order)
            li.append(char)
    return "".join(li)   

enc= encryption()
print("Text after encryption:\n", enc)    

def decryption(enc):
    li=[]
    print("\nThe decrypted form of the encrypted text is:\n")
    u_inp= enc
    for letter in u_inp:
        if letter == " ":
            li.append(letter)          
        else:
            order= ord(letter)
            order= order-1
            char= chr(order)
            li.append(char)
    print("".join(li))   
decryption(enc)    
#bejuj tijwboj