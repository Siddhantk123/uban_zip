def reverse():
    for i in range(5,0,-2):
        print(i)
#reverse()        
def summation():
    s1= sum([1,2,3,4]) #passing iterables - list 
    s2=sum((1,2,3,4))   #passing iterables- sets
    print(s1, s2)
#summation()    
def fetching():
    lis1=["man","girl"]
    print(lis1[0][0])
#fetching()    #output: m
