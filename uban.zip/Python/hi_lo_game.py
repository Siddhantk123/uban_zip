#binary search
print("Please think of number between 1 to 1000")
input("and Press ENTER")


low = 1
high = 10000
while True:
    mid = (low+high)//2
    print("did you think the number {} ? if yes,".format(mid))
    inp=input("if yes then press c for exiting or specify h or l for value high or low from the number shown respectively")
    if inp == 'c':
        break
    elif inp == 'h':
        low = mid+1
    else:
            

                
        


        