# f= open("1.txt","w")
# f.write("hello Siddhant")

# f= open("1.txt","a")
# f.write("\nhow are you?")


# f= open("1.txt")
# print(f.readline())
# print(f.readline())


# f= open("1.txt","r+")   #read and write mode together
# print(f.read())
# f.write("welcome to gorakhpur")
# f.close()

with open("2.txt","a") as f:
    # print(f.read())
    f.write("\nWhen I get a chance to travel the whole world")
print("success")




