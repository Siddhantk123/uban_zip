# how to come in one dir
# search for .txt file
# open, search -> peace
# peace ki freq and location

import os
# 1.Get file names from directory
file_list=os.listdir()
lis=[]
c=0
k=0
for file in file_list:
    if file.endswith(".txt"):
        k=0
        c=0
        with open(file,"r") as f:
            read= f.read()
            lis= read.split(" ") 
            for word in lis:
                if word == "peace":
                    k=1
                    c=c+1
            if k == 1:
                print(f"file name: {file} and frequency is: {c}")
                
                        


 
