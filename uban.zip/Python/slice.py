#       01234567890123456789012345
str1 = "abcdefghijklmnopqrstuvwxyz"
print(len(str1))
print(str1[0:25])
print(str1[25:0:-1])
print(str1[:])
print(str1[-1:0:-1])
print(str1[-10:-13:-1])   #qpo
print(str1[16:13:-1])   #qpo
print(str1[-22:-27:-1])   #edcba
print(str1[-1:-9:-1])   #qpo